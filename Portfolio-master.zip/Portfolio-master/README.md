# Visit my portfolio at [dub.sh/ankitdey](https://dub.sh/ankitdey)

This is my personal website made purely in javascript using React and Tailwind CSS.

## Socials

- __Ankit Dey(Me)__
  
    - Portfolio : https://dub.sh/ankitdey/
    - Twitter : https://twitter.com/marshdit/
    - Github : https://github.com/ankitdey-marsh/
    - Mastodon: https://mastodon.social/@ankit_dey
